import React from 'react'

const Error500 = () => {
  return (
    <div>
      error 500 is here man!
    </div>
  )
}

export default Error500
